#include <stdio.h>
#include "aref.h"
#include "strCol.h"

void scanDirTree( char *path, StrShare *pathShare, RefArray *origRef, RefArray *sortRef ); 
void list_dir(char *path);
